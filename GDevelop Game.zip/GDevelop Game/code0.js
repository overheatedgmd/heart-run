gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.localVariables = [];
gdjs.Untitled_32sceneCode.GDCard1Objects1_2final = [];

gdjs.Untitled_32sceneCode.GDCard1Objects2_1final = [];

gdjs.Untitled_32sceneCode.GDCard1Objects2_2final = [];

gdjs.Untitled_32sceneCode.GDCard1Objects3_1final = [];

gdjs.Untitled_32sceneCode.GDCard2Objects1_2final = [];

gdjs.Untitled_32sceneCode.GDCard2Objects2_1final = [];

gdjs.Untitled_32sceneCode.GDCard2Objects2_2final = [];

gdjs.Untitled_32sceneCode.GDCard2Objects3_1final = [];

gdjs.Untitled_32sceneCode.GDCard3Objects1_2final = [];

gdjs.Untitled_32sceneCode.GDCard3Objects2_1final = [];

gdjs.Untitled_32sceneCode.GDCard3Objects2_2final = [];

gdjs.Untitled_32sceneCode.GDCard3Objects3_1final = [];

gdjs.Untitled_32sceneCode.GDCard4Objects1_2final = [];

gdjs.Untitled_32sceneCode.GDCard4Objects2_1final = [];

gdjs.Untitled_32sceneCode.GDCard4Objects2_2final = [];

gdjs.Untitled_32sceneCode.GDCard4Objects3_1final = [];

gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1_2final = [];

gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_1final = [];

gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final = [];

gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final = [];

gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects1= [];
gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2= [];
gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects3= [];
gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects4= [];
gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects5= [];
gdjs.Untitled_32sceneCode.GDCard1Objects1= [];
gdjs.Untitled_32sceneCode.GDCard1Objects2= [];
gdjs.Untitled_32sceneCode.GDCard1Objects3= [];
gdjs.Untitled_32sceneCode.GDCard1Objects4= [];
gdjs.Untitled_32sceneCode.GDCard1Objects5= [];
gdjs.Untitled_32sceneCode.GDBoardObjects1= [];
gdjs.Untitled_32sceneCode.GDBoardObjects2= [];
gdjs.Untitled_32sceneCode.GDBoardObjects3= [];
gdjs.Untitled_32sceneCode.GDBoardObjects4= [];
gdjs.Untitled_32sceneCode.GDBoardObjects5= [];
gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects3= [];
gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects4= [];
gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects5= [];
gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects3= [];
gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects4= [];
gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects5= [];
gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects3= [];
gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects4= [];
gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects5= [];
gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects3= [];
gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects4= [];
gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects5= [];
gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects3= [];
gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects4= [];
gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects5= [];
gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects3= [];
gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects4= [];
gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects5= [];
gdjs.Untitled_32sceneCode.GDPointsDisplayObjects1= [];
gdjs.Untitled_32sceneCode.GDPointsDisplayObjects2= [];
gdjs.Untitled_32sceneCode.GDPointsDisplayObjects3= [];
gdjs.Untitled_32sceneCode.GDPointsDisplayObjects4= [];
gdjs.Untitled_32sceneCode.GDPointsDisplayObjects5= [];
gdjs.Untitled_32sceneCode.GDgameovertextObjects1= [];
gdjs.Untitled_32sceneCode.GDgameovertextObjects2= [];
gdjs.Untitled_32sceneCode.GDgameovertextObjects3= [];
gdjs.Untitled_32sceneCode.GDgameovertextObjects4= [];
gdjs.Untitled_32sceneCode.GDgameovertextObjects5= [];
gdjs.Untitled_32sceneCode.GDRoundsDisplayObjects1= [];
gdjs.Untitled_32sceneCode.GDRoundsDisplayObjects2= [];
gdjs.Untitled_32sceneCode.GDRoundsDisplayObjects3= [];
gdjs.Untitled_32sceneCode.GDRoundsDisplayObjects4= [];
gdjs.Untitled_32sceneCode.GDRoundsDisplayObjects5= [];
gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects1= [];
gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects2= [];
gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects3= [];
gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects4= [];
gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects5= [];
gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects3= [];
gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects4= [];
gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects5= [];
gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects3= [];
gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects4= [];
gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects5= [];
gdjs.Untitled_32sceneCode.GDCard2Objects1= [];
gdjs.Untitled_32sceneCode.GDCard2Objects2= [];
gdjs.Untitled_32sceneCode.GDCard2Objects3= [];
gdjs.Untitled_32sceneCode.GDCard2Objects4= [];
gdjs.Untitled_32sceneCode.GDCard2Objects5= [];
gdjs.Untitled_32sceneCode.GDCard3Objects1= [];
gdjs.Untitled_32sceneCode.GDCard3Objects2= [];
gdjs.Untitled_32sceneCode.GDCard3Objects3= [];
gdjs.Untitled_32sceneCode.GDCard3Objects4= [];
gdjs.Untitled_32sceneCode.GDCard3Objects5= [];
gdjs.Untitled_32sceneCode.GDCard4Objects1= [];
gdjs.Untitled_32sceneCode.GDCard4Objects2= [];
gdjs.Untitled_32sceneCode.GDCard4Objects3= [];
gdjs.Untitled_32sceneCode.GDCard4Objects4= [];
gdjs.Untitled_32sceneCode.GDCard4Objects5= [];
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1= [];
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2= [];
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3= [];
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4= [];
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects5= [];
gdjs.Untitled_32sceneCode.GDYourCardTextObjects1= [];
gdjs.Untitled_32sceneCode.GDYourCardTextObjects2= [];
gdjs.Untitled_32sceneCode.GDYourCardTextObjects3= [];
gdjs.Untitled_32sceneCode.GDYourCardTextObjects4= [];
gdjs.Untitled_32sceneCode.GDYourCardTextObjects5= [];
gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects1= [];
gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2= [];
gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects3= [];
gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects4= [];
gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects5= [];
gdjs.Untitled_32sceneCode.GDPointsTextObjects1= [];
gdjs.Untitled_32sceneCode.GDPointsTextObjects2= [];
gdjs.Untitled_32sceneCode.GDPointsTextObjects3= [];
gdjs.Untitled_32sceneCode.GDPointsTextObjects4= [];
gdjs.Untitled_32sceneCode.GDPointsTextObjects5= [];
gdjs.Untitled_32sceneCode.GDHandsElapsedTextObjects1= [];
gdjs.Untitled_32sceneCode.GDHandsElapsedTextObjects2= [];
gdjs.Untitled_32sceneCode.GDHandsElapsedTextObjects3= [];
gdjs.Untitled_32sceneCode.GDHandsElapsedTextObjects4= [];
gdjs.Untitled_32sceneCode.GDHandsElapsedTextObjects5= [];
gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects1= [];
gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects2= [];
gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects3= [];
gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects4= [];
gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects5= [];
gdjs.Untitled_32sceneCode.GDBackgroundObjects1= [];
gdjs.Untitled_32sceneCode.GDBackgroundObjects2= [];
gdjs.Untitled_32sceneCode.GDBackgroundObjects3= [];
gdjs.Untitled_32sceneCode.GDBackgroundObjects4= [];
gdjs.Untitled_32sceneCode.GDBackgroundObjects5= [];
gdjs.Untitled_32sceneCode.GDx2PointsButtonTextObjects1= [];
gdjs.Untitled_32sceneCode.GDx2PointsButtonTextObjects2= [];
gdjs.Untitled_32sceneCode.GDx2PointsButtonTextObjects3= [];
gdjs.Untitled_32sceneCode.GDx2PointsButtonTextObjects4= [];
gdjs.Untitled_32sceneCode.GDx2PointsButtonTextObjects5= [];
gdjs.Untitled_32sceneCode.GDchoosetextObjects1= [];
gdjs.Untitled_32sceneCode.GDchoosetextObjects2= [];
gdjs.Untitled_32sceneCode.GDchoosetextObjects3= [];
gdjs.Untitled_32sceneCode.GDchoosetextObjects4= [];
gdjs.Untitled_32sceneCode.GDchoosetextObjects5= [];
gdjs.Untitled_32sceneCode.GDReduceLossPointsButtonTextObjects1= [];
gdjs.Untitled_32sceneCode.GDReduceLossPointsButtonTextObjects2= [];
gdjs.Untitled_32sceneCode.GDReduceLossPointsButtonTextObjects3= [];
gdjs.Untitled_32sceneCode.GDReduceLossPointsButtonTextObjects4= [];
gdjs.Untitled_32sceneCode.GDReduceLossPointsButtonTextObjects5= [];
gdjs.Untitled_32sceneCode.GDRulesObjects1= [];
gdjs.Untitled_32sceneCode.GDRulesObjects2= [];
gdjs.Untitled_32sceneCode.GDRulesObjects3= [];
gdjs.Untitled_32sceneCode.GDRulesObjects4= [];
gdjs.Untitled_32sceneCode.GDRulesObjects5= [];
gdjs.Untitled_32sceneCode.GDRulesButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDRulesButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDRulesButtonObjects3= [];
gdjs.Untitled_32sceneCode.GDRulesButtonObjects4= [];
gdjs.Untitled_32sceneCode.GDRulesButtonObjects5= [];


gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDStart_95959595ButtonObjects2Objects = Hashtable.newFrom({"Start_Button": gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDStart_95959595ButtonObjects2Objects = Hashtable.newFrom({"Start_Button": gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDStart_95959595ButtonObjects1Objects = Hashtable.newFrom({"Start_Button": gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects1});
gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Start_Button"), gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDStart_95959595ButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2[i].getBehavior("Opacity").getOpacity() == 255 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2[k] = gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Start_Hand_Text"), gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Start_Button"), gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDStart_95959595ButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2[i].getBehavior("Effect").setEffectDoubleParameter("Brightnesscontrol", "brightness", 1.0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Start_Button"), gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDStart_95959595ButtonObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects1[i].getBehavior("Effect").setEffectDoubleParameter("Brightnesscontrol", "brightness", 0.8);
}
}}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDDouble_95959595Points_95959595ButtonObjects2Objects = Hashtable.newFrom({"Double_Points_Button": gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDReduced_95959595Loss_95959595ButtonObjects1Objects = Hashtable.newFrom({"Reduced_Loss_Button": gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects1});
gdjs.Untitled_32sceneCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Double_Points_Button"), gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDDouble_95959595Points_95959595ButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2[i].getBehavior("Opacity").getOpacity() == 255 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2[k] = gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Reduced_Loss_Button"), gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{runtimeScene.getScene().getVariables().getFromIndex(14).mul(2);
}{runtimeScene.getScene().getVariables().getFromIndex(2).add(1);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Reduced_Loss_Button"), gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDReduced_95959595Loss_95959595ButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects1[i].getBehavior("Opacity").getOpacity() == 255 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects1[k] = gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects1.length = k;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Double_Points_Button"), gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects1);
/* Reuse gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{runtimeScene.getScene().getVariables().getFromIndex(15).mul(0.5);
}{runtimeScene.getScene().getVariables().getFromIndex(2).add(1);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}}

}


};gdjs.Untitled_32sceneCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(1).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 5);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber() >= 130);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10895548);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Double_Points_Button"), gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Reduced_Loss_Button"), gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(255);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(1).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 10);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber() >= 200);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10899284);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Double_Points_Button"), gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Reduced_Loss_Button"), gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(255);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(1).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 15);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber() >= 275);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10903044);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Double_Points_Button"), gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Reduced_Loss_Button"), gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(255);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(1).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 20);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber() >= 350);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10906940);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Double_Points_Button"), gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Reduced_Loss_Button"), gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects1[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects1[i].getBehavior("Opacity").setOpacity(255);
}
}}

}


};gdjs.Untitled_32sceneCode.asyncCallback10944956 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(3).setBoolean(true);
}gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList3 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback10944956(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.asyncCallback9470516 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects4);

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects4.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects4[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard2Objects4[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomInRange(1, 4));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects4.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects4[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard2Objects4[i].getVariables().getFromIndex(1)).setBoolean(true);
}
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList3(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList4 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
for (const obj of gdjs.Untitled_32sceneCode.GDCard2Objects3) asyncObjectsList.addObject("Card2", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.6), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback9470516(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.asyncCallback10634028 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects3);

gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects3);
gdjs.copyArray(asyncObjectsList.getObjects("Dealer_Deck"), gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects3);

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects3[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard1Objects3[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomInRange(1, 4));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects3[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard1Objects3[i].getVariables().getFromIndex(1)).setBoolean(true);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects3[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects3[i].getBehavior("Animation").setAnimationName("Face_Down");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects3[i].setPosition((( gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects3.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects3[0].getPointX("")),(( gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects3.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects3[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects3[i].getBehavior("Tween").addObjectPositionTween2("move1", 693, 277, "easeInOutQuad", 0.5, false);
}
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList4(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList5 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
for (const obj of gdjs.Untitled_32sceneCode.GDCard1Objects2) asyncObjectsList.addObject("Card1", obj);
for (const obj of gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2) asyncObjectsList.addObject("Dealer_Deck", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.6), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback10634028(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.asyncCallback10059492 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects2);
gdjs.copyArray(asyncObjectsList.getObjects("Dealer_Deck"), gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2);

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i].returnVariable(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomInRange(1, 4));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i].returnVariable(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i].getVariables().getFromIndex(1)).setBoolean(true);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects2[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects2[i].getBehavior("Animation").setAnimationName("Face_Down");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects2[i].setPosition((( gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2[0].getPointX("")),(( gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects2[i].getBehavior("Tween").addObjectPositionTween2("move1", 554, 277, "easeInOutQuad", 0.5, false);
}
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList5(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
for (const obj of gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects1) asyncObjectsList.addObject("Dealer_Deck", obj);
for (const obj of gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1) asyncObjectsList.addObject("Player_Card", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.6), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback10059492(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 5);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 10);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 15);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 20);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10910756);
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bet_Four_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_High_Card_Button"), gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_One_Of_Each_Button"), gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_Pair_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_Three_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Board"), gdjs.Untitled_32sceneCode.GDBoardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Dealer_Deck"), gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2);
gdjs.copyArray(runtimeScene.getObjects("Double_Points_Button"), gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Reduced_Loss_Button"), gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Start_Button"), gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Start_Hand_Text"), gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2[i].getBehavior("Opacity").setOpacity(255);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).add(1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoardObjects2[i].getBehavior("Opacity").setOpacity(255);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 5);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber() >= 130);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10758124);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bet_Four_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_High_Card_Button"), gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_One_Of_Each_Button"), gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_Pair_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_Three_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Board"), gdjs.Untitled_32sceneCode.GDBoardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Dealer_Deck"), gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Start_Button"), gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Start_Hand_Text"), gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoardObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 10);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber() >= 200);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9169444);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bet_Four_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_High_Card_Button"), gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_One_Of_Each_Button"), gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_Pair_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_Three_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Board"), gdjs.Untitled_32sceneCode.GDBoardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Dealer_Deck"), gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Start_Button"), gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Start_Hand_Text"), gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoardObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 15);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber() >= 275);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10819524);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bet_Four_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_High_Card_Button"), gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_One_Of_Each_Button"), gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_Pair_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_Three_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Board"), gdjs.Untitled_32sceneCode.GDBoardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Dealer_Deck"), gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Start_Button"), gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Start_Hand_Text"), gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoardObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 20);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber() >= 350);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10920108);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bet_Four_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_High_Card_Button"), gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_One_Of_Each_Button"), gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_Pair_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_Three_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Board"), gdjs.Untitled_32sceneCode.GDBoardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Dealer_Deck"), gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Start_Button"), gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Start_Hand_Text"), gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoardObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 5);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber() < 130);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9239300);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bet_Four_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_High_Card_Button"), gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_One_Of_Each_Button"), gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_Pair_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_Three_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Board"), gdjs.Untitled_32sceneCode.GDBoardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Dealer_Deck"), gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("gameovertext"), gdjs.Untitled_32sceneCode.GDgameovertextObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoardObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgameovertextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgameovertextObjects2[i].getBehavior("Opacity").setOpacity(255);
}
}{runtimeScene.getScene().getVariables().getFromIndex(11).setBoolean(false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 10);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber() < 200);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9734020);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bet_Four_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_High_Card_Button"), gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_One_Of_Each_Button"), gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_Pair_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_Three_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Board"), gdjs.Untitled_32sceneCode.GDBoardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Dealer_Deck"), gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("gameovertext"), gdjs.Untitled_32sceneCode.GDgameovertextObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoardObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgameovertextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgameovertextObjects2[i].getBehavior("Opacity").setOpacity(255);
}
}{runtimeScene.getScene().getVariables().getFromIndex(11).setBoolean(false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 15);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber() < 275);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9881324);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bet_Four_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_High_Card_Button"), gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_One_Of_Each_Button"), gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_Pair_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_Three_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Board"), gdjs.Untitled_32sceneCode.GDBoardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Dealer_Deck"), gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("gameovertext"), gdjs.Untitled_32sceneCode.GDgameovertextObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoardObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgameovertextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgameovertextObjects2[i].getBehavior("Opacity").setOpacity(255);
}
}{runtimeScene.getScene().getVariables().getFromIndex(11).setBoolean(false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 20);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber() < 350);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10930092);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bet_Four_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_High_Card_Button"), gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_One_Of_Each_Button"), gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_Pair_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_Three_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Board"), gdjs.Untitled_32sceneCode.GDBoardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Dealer_Deck"), gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("gameovertext"), gdjs.Untitled_32sceneCode.GDgameovertextObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoardObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgameovertextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgameovertextObjects2[i].getBehavior("Opacity").setOpacity(255);
}
}{runtimeScene.getScene().getVariables().getFromIndex(11).setBoolean(false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(1).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10940300);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Dealer_Deck"), gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1[i].getBehavior("Animation").setAnimationName("Face_Down");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1[i].setPosition((( gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects1[0].getPointX("")),(( gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects1[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1[i].getBehavior("Tween").addObjectPositionTween2("move1", 132, 277, "easeInOutQuad", 0.5, false);
}
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.Untitled_32sceneCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(3).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10946508);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bet_Four_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bet_High_Card_Button"), gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bet_One_Of_Each_Button"), gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bet_Pair_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bet_Three_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(false);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects1[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects1[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects1[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects1[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects1[i].getBehavior("Opacity").setOpacity(255);
}
}}

}


};gdjs.Untitled_32sceneCode.asyncCallback9469092 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects3);
gdjs.copyArray(asyncObjectsList.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects3);

gdjs.copyArray(asyncObjectsList.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects3);

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects3[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard4Objects3[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomInRange(1, 4));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects3[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard4Objects3[i].getVariables().getFromIndex(1)).setBoolean(true);
}
}{runtimeScene.getScene().getVariables().getFromIndex(12).setNumber(((gdjs.Untitled_32sceneCode.GDCard1Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard1Objects3[0].getVariables()).getFromIndex(0).getAsNumber() + ((gdjs.Untitled_32sceneCode.GDCard2Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard2Objects3[0].getVariables()).getFromIndex(0).getAsNumber() + ((gdjs.Untitled_32sceneCode.GDCard3Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard3Objects3[0].getVariables()).getFromIndex(0).getAsNumber() + ((gdjs.Untitled_32sceneCode.GDCard4Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard4Objects3[0].getVariables()).getFromIndex(0).getAsNumber());
}gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList9 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
for (const obj of gdjs.Untitled_32sceneCode.GDCard3Objects2) asyncObjectsList.addObject("Card3", obj);
for (const obj of gdjs.Untitled_32sceneCode.GDCard4Objects2) asyncObjectsList.addObject("Card4", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.6), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback9469092(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.asyncCallback9230308 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects2);

gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects2);
gdjs.copyArray(asyncObjectsList.getObjects("Dealer_Deck"), gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2);

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects2[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard3Objects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomInRange(1, 4));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects2[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard3Objects2[i].getVariables().getFromIndex(1)).setBoolean(true);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getBehavior("Animation").setAnimationName("Face_Down");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects2[i].setPosition((( gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2[0].getPointX("")),(( gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getBehavior("Tween").addObjectPositionTween2("move1", 953, 277, "easeInOutQuad", 0.5, false);
}
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList9(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList10 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
for (const obj of gdjs.Untitled_32sceneCode.GDCard3Objects1) asyncObjectsList.addObject("Card3", obj);
for (const obj of gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects1) asyncObjectsList.addObject("Dealer_Deck", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.6), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback9230308(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(6).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10950980);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bet_Four_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bet_High_Card_Button"), gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bet_One_Of_Each_Button"), gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bet_Pair_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Bet_Three_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Dealer_Deck"), gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects1[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects1[i].getBehavior("Animation").setAnimationName("Face_Down");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects1[i].setPosition((( gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects1[0].getPointX("")),(( gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects1[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects1[i].getBehavior("Tween").addObjectPositionTween2("move1", 824, 277, "easeInOutQuad", 0.5, false);
}
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.Untitled_32sceneCode.asyncCallback10512828 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(false);
}gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList12 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback10512828(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.asyncCallback10924196 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(7).add(10 * runtimeScene.getScene().getVariables().getFromIndex(14).getAsNumber());
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList12(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList13 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback10924196(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.asyncCallback9343260 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(false);
}gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList14 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback9343260(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.asyncCallback8222636 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(7).sub(10 * runtimeScene.getScene().getVariables().getFromIndex(15).getAsNumber());
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList14(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList15 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback8222636(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.eventsList16 = function(runtimeScene) {

{

gdjs.Untitled_32sceneCode.GDCard1Objects3.length = 0;

gdjs.Untitled_32sceneCode.GDCard2Objects3.length = 0;

gdjs.Untitled_32sceneCode.GDCard3Objects3.length = 0;

gdjs.Untitled_32sceneCode.GDCard4Objects3.length = 0;

gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(6).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber() == 10);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Untitled_32sceneCode.GDCard1Objects3_1final.length = 0;
gdjs.Untitled_32sceneCode.GDCard2Objects3_1final.length = 0;
gdjs.Untitled_32sceneCode.GDCard3Objects3_1final.length = 0;
gdjs.Untitled_32sceneCode.GDCard4Objects3_1final.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4);
{isConditionTrue_1 = (((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDCard1Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard1Objects4[0].getVariables()).getFromIndex(0).getAsNumber());
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard1Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard1Objects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard1Objects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard1Objects3_1final.push(gdjs.Untitled_32sceneCode.GDCard1Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4);
{isConditionTrue_1 = (((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDCard2Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard2Objects4[0].getVariables()).getFromIndex(0).getAsNumber());
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard2Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard2Objects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard2Objects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard2Objects3_1final.push(gdjs.Untitled_32sceneCode.GDCard2Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects4);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4);
{isConditionTrue_1 = (((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDCard3Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard3Objects4[0].getVariables()).getFromIndex(0).getAsNumber());
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard3Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard3Objects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard3Objects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard3Objects3_1final.push(gdjs.Untitled_32sceneCode.GDCard3Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects4);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4);
{isConditionTrue_1 = (((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDCard4Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard4Objects4[0].getVariables()).getFromIndex(0).getAsNumber());
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard4Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard4Objects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard4Objects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard4Objects3_1final.push(gdjs.Untitled_32sceneCode.GDCard4Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard1Objects3_1final, gdjs.Untitled_32sceneCode.GDCard1Objects3);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard2Objects3_1final, gdjs.Untitled_32sceneCode.GDCard2Objects3);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard3Objects3_1final, gdjs.Untitled_32sceneCode.GDCard3Objects3);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard4Objects3_1final, gdjs.Untitled_32sceneCode.GDCard4Objects3);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final, gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10921444);
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList13(runtimeScene);} //End of subevents
}

}


{

gdjs.Untitled_32sceneCode.GDCard1Objects2.length = 0;

gdjs.Untitled_32sceneCode.GDCard2Objects2.length = 0;

gdjs.Untitled_32sceneCode.GDCard3Objects2.length = 0;

gdjs.Untitled_32sceneCode.GDCard4Objects2.length = 0;

gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(6).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber() == 10);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
{gdjs.Untitled_32sceneCode.GDCard1Objects2_2final.length = 0;
gdjs.Untitled_32sceneCode.GDCard2Objects2_2final.length = 0;
gdjs.Untitled_32sceneCode.GDCard3Objects2_2final.length = 0;
gdjs.Untitled_32sceneCode.GDCard4Objects2_2final.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDCard1Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard1Objects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard1Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard1Objects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard1Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard1Objects2_2final.push(gdjs.Untitled_32sceneCode.GDCard1Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDCard2Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard2Objects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard2Objects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard2Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard2Objects2_2final.push(gdjs.Untitled_32sceneCode.GDCard2Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDCard3Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard3Objects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard3Objects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard3Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard3Objects2_2final.push(gdjs.Untitled_32sceneCode.GDCard3Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDCard4Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard4Objects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard4Objects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard4Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard4Objects2_2final.push(gdjs.Untitled_32sceneCode.GDCard4Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard1Objects2_2final, gdjs.Untitled_32sceneCode.GDCard1Objects2);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard2Objects2_2final, gdjs.Untitled_32sceneCode.GDCard2Objects2);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard3Objects2_2final, gdjs.Untitled_32sceneCode.GDCard3Objects2);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard4Objects2_2final, gdjs.Untitled_32sceneCode.GDCard4Objects2);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final, gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2);
}
}
isConditionTrue_0 = !isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10759812);
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.Untitled_32sceneCode.asyncCallback10681404 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(false);
}gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList17 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback10681404(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.asyncCallback9403724 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(7).add(20 * runtimeScene.getScene().getVariables().getFromIndex(14).getAsNumber());
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList17(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList18 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback9403724(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.asyncCallback10919820 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(false);
}gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList19 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback10919820(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.asyncCallback10886124 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(7).sub(20 * runtimeScene.getScene().getVariables().getFromIndex(15).getAsNumber());
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList19(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList20 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback10886124(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.eventsList21 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(6).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber() == 20);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(12).getAsNumber() - 1 == 10);
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(12).getAsNumber() - 2 == 10);
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(12).getAsNumber() - 3 == 10);
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(12).getAsNumber() - 4 == 10);
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10515764);
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList18(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(6).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber() == 20);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
{let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
{isConditionTrue_2 = (runtimeScene.getScene().getVariables().getFromIndex(12).getAsNumber() - 1 == 10);
}
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
{isConditionTrue_2 = (runtimeScene.getScene().getVariables().getFromIndex(12).getAsNumber() - 2 == 10);
}
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
{isConditionTrue_2 = (runtimeScene.getScene().getVariables().getFromIndex(12).getAsNumber() - 3 == 10);
}
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
{isConditionTrue_2 = (runtimeScene.getScene().getVariables().getFromIndex(12).getAsNumber() - 4 == 10);
}
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
}
}
isConditionTrue_0 = !isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10885988);
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList20(runtimeScene);} //End of subevents
}

}


};gdjs.Untitled_32sceneCode.asyncCallback7945396 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(false);
}gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList22 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback7945396(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.asyncCallback7945324 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(7).add(30 * runtimeScene.getScene().getVariables().getFromIndex(14).getAsNumber());
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList22(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList23 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback7945324(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.asyncCallback9311700 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(false);
}gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList24 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback9311700(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.asyncCallback9444988 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(7).sub(30 * runtimeScene.getScene().getVariables().getFromIndex(15).getAsNumber());
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList24(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList25 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback9444988(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.eventsList26 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(6).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber() == 30);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
{isConditionTrue_1 = !(((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDCard1Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard1Objects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = !(((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDCard2Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard2Objects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = !(((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDCard3Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard3Objects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = !(((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDCard4Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard4Objects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(8367588);
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList23(runtimeScene);} //End of subevents
}

}


{

gdjs.Untitled_32sceneCode.GDCard1Objects2.length = 0;

gdjs.Untitled_32sceneCode.GDCard2Objects2.length = 0;

gdjs.Untitled_32sceneCode.GDCard3Objects2.length = 0;

gdjs.Untitled_32sceneCode.GDCard4Objects2.length = 0;

gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(6).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber() == 30);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Untitled_32sceneCode.GDCard1Objects2_1final.length = 0;
gdjs.Untitled_32sceneCode.GDCard2Objects2_1final.length = 0;
gdjs.Untitled_32sceneCode.GDCard3Objects2_1final.length = 0;
gdjs.Untitled_32sceneCode.GDCard4Objects2_1final.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);
{isConditionTrue_1 = (((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDCard1Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard1Objects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard1Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard1Objects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard1Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard1Objects2_1final.push(gdjs.Untitled_32sceneCode.GDCard1Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_1final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);
{isConditionTrue_1 = (((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDCard2Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard2Objects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard2Objects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard2Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard2Objects2_1final.push(gdjs.Untitled_32sceneCode.GDCard2Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_1final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);
{isConditionTrue_1 = (((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDCard3Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard3Objects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard3Objects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard3Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard3Objects2_1final.push(gdjs.Untitled_32sceneCode.GDCard3Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_1final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);
{isConditionTrue_1 = (((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDCard4Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard4Objects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard4Objects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard4Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard4Objects2_1final.push(gdjs.Untitled_32sceneCode.GDCard4Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_1final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard1Objects2_1final, gdjs.Untitled_32sceneCode.GDCard1Objects2);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard2Objects2_1final, gdjs.Untitled_32sceneCode.GDCard2Objects2);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard3Objects2_1final, gdjs.Untitled_32sceneCode.GDCard3Objects2);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard4Objects2_1final, gdjs.Untitled_32sceneCode.GDCard4Objects2);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_1final, gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9444916);
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList25(runtimeScene);} //End of subevents
}

}


};gdjs.Untitled_32sceneCode.asyncCallback10729716 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(false);
}gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList27 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback10729716(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.asyncCallback8394028 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(7).add(40 * runtimeScene.getScene().getVariables().getFromIndex(14).getAsNumber());
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList27(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList28 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback8394028(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.asyncCallback10916484 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(false);
}gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList29 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback10916484(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.asyncCallback10513292 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(7).sub(40 * runtimeScene.getScene().getVariables().getFromIndex(15).getAsNumber());
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList29(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList30 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback10513292(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.eventsList31 = function(runtimeScene) {

{

gdjs.Untitled_32sceneCode.GDCard1Objects3.length = 0;

gdjs.Untitled_32sceneCode.GDCard2Objects3.length = 0;

gdjs.Untitled_32sceneCode.GDCard3Objects3.length = 0;

gdjs.Untitled_32sceneCode.GDCard4Objects3.length = 0;

gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(6).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber() == 40);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Untitled_32sceneCode.GDCard1Objects3_1final.length = 0;
gdjs.Untitled_32sceneCode.GDCard2Objects3_1final.length = 0;
gdjs.Untitled_32sceneCode.GDCard3Objects3_1final.length = 0;
gdjs.Untitled_32sceneCode.GDCard4Objects3_1final.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDCard1Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard1Objects4[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDCard2Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard2Objects4[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[0].getVariables()).getFromIndex(0).getAsNumber());
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard1Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard1Objects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard1Objects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard1Objects3_1final.push(gdjs.Untitled_32sceneCode.GDCard1Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard2Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard2Objects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard2Objects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard2Objects3_1final.push(gdjs.Untitled_32sceneCode.GDCard2Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects4);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDCard1Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard1Objects4[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDCard3Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard3Objects4[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[0].getVariables()).getFromIndex(0).getAsNumber());
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard1Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard1Objects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard1Objects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard1Objects3_1final.push(gdjs.Untitled_32sceneCode.GDCard1Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard3Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard3Objects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard3Objects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard3Objects3_1final.push(gdjs.Untitled_32sceneCode.GDCard3Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects4);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDCard1Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard1Objects4[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDCard4Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard4Objects4[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[0].getVariables()).getFromIndex(0).getAsNumber());
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard1Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard1Objects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard1Objects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard1Objects3_1final.push(gdjs.Untitled_32sceneCode.GDCard1Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard4Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard4Objects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard4Objects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard4Objects3_1final.push(gdjs.Untitled_32sceneCode.GDCard4Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects4);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDCard2Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard2Objects4[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDCard3Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard3Objects4[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[0].getVariables()).getFromIndex(0).getAsNumber());
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard2Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard2Objects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard2Objects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard2Objects3_1final.push(gdjs.Untitled_32sceneCode.GDCard2Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard3Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard3Objects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard3Objects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard3Objects3_1final.push(gdjs.Untitled_32sceneCode.GDCard3Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects4);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDCard2Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard2Objects4[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDCard4Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard4Objects4[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[0].getVariables()).getFromIndex(0).getAsNumber());
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard2Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard2Objects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard2Objects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard2Objects3_1final.push(gdjs.Untitled_32sceneCode.GDCard2Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard4Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard4Objects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard4Objects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard4Objects3_1final.push(gdjs.Untitled_32sceneCode.GDCard4Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects4);
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects4);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDCard3Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard3Objects4[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDCard4Objects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard4Objects4[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[0].getVariables()).getFromIndex(0).getAsNumber());
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard3Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard3Objects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard3Objects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard3Objects3_1final.push(gdjs.Untitled_32sceneCode.GDCard3Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard4Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard4Objects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard4Objects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard4Objects3_1final.push(gdjs.Untitled_32sceneCode.GDCard4Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard1Objects3_1final, gdjs.Untitled_32sceneCode.GDCard1Objects3);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard2Objects3_1final, gdjs.Untitled_32sceneCode.GDCard2Objects3);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard3Objects3_1final, gdjs.Untitled_32sceneCode.GDCard3Objects3);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard4Objects3_1final, gdjs.Untitled_32sceneCode.GDCard4Objects3);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3_1final, gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9639700);
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList28(runtimeScene);} //End of subevents
}

}


{

gdjs.Untitled_32sceneCode.GDCard1Objects2.length = 0;

gdjs.Untitled_32sceneCode.GDCard2Objects2.length = 0;

gdjs.Untitled_32sceneCode.GDCard3Objects2.length = 0;

gdjs.Untitled_32sceneCode.GDCard4Objects2.length = 0;

gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(6).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber() == 40);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
{gdjs.Untitled_32sceneCode.GDCard1Objects2_2final.length = 0;
gdjs.Untitled_32sceneCode.GDCard2Objects2_2final.length = 0;
gdjs.Untitled_32sceneCode.GDCard3Objects2_2final.length = 0;
gdjs.Untitled_32sceneCode.GDCard4Objects2_2final.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);
{let isConditionTrue_3 = false;
isConditionTrue_3 = false;
{isConditionTrue_3 = (((gdjs.Untitled_32sceneCode.GDCard1Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard1Objects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_3) {
isConditionTrue_3 = false;
{isConditionTrue_3 = (((gdjs.Untitled_32sceneCode.GDCard2Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard2Objects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
}
isConditionTrue_2 = isConditionTrue_3;
}
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard1Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard1Objects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard1Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard1Objects2_2final.push(gdjs.Untitled_32sceneCode.GDCard1Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard2Objects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard2Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard2Objects2_2final.push(gdjs.Untitled_32sceneCode.GDCard2Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);
{let isConditionTrue_3 = false;
isConditionTrue_3 = false;
{isConditionTrue_3 = (((gdjs.Untitled_32sceneCode.GDCard1Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard1Objects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_3) {
isConditionTrue_3 = false;
{isConditionTrue_3 = (((gdjs.Untitled_32sceneCode.GDCard3Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard3Objects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
}
isConditionTrue_2 = isConditionTrue_3;
}
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard1Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard1Objects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard1Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard1Objects2_2final.push(gdjs.Untitled_32sceneCode.GDCard1Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard3Objects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard3Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard3Objects2_2final.push(gdjs.Untitled_32sceneCode.GDCard3Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);
{let isConditionTrue_3 = false;
isConditionTrue_3 = false;
{isConditionTrue_3 = (((gdjs.Untitled_32sceneCode.GDCard1Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard1Objects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_3) {
isConditionTrue_3 = false;
{isConditionTrue_3 = (((gdjs.Untitled_32sceneCode.GDCard4Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard4Objects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
}
isConditionTrue_2 = isConditionTrue_3;
}
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard1Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard1Objects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard1Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard1Objects2_2final.push(gdjs.Untitled_32sceneCode.GDCard1Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard4Objects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard4Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard4Objects2_2final.push(gdjs.Untitled_32sceneCode.GDCard4Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);
{let isConditionTrue_3 = false;
isConditionTrue_3 = false;
{isConditionTrue_3 = (((gdjs.Untitled_32sceneCode.GDCard2Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard2Objects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_3) {
isConditionTrue_3 = false;
{isConditionTrue_3 = (((gdjs.Untitled_32sceneCode.GDCard3Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard3Objects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
}
isConditionTrue_2 = isConditionTrue_3;
}
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard2Objects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard2Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard2Objects2_2final.push(gdjs.Untitled_32sceneCode.GDCard2Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard3Objects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard3Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard3Objects2_2final.push(gdjs.Untitled_32sceneCode.GDCard3Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);
{let isConditionTrue_3 = false;
isConditionTrue_3 = false;
{isConditionTrue_3 = (((gdjs.Untitled_32sceneCode.GDCard2Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard2Objects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_3) {
isConditionTrue_3 = false;
{isConditionTrue_3 = (((gdjs.Untitled_32sceneCode.GDCard4Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard4Objects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
}
isConditionTrue_2 = isConditionTrue_3;
}
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard2Objects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard2Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard2Objects2_2final.push(gdjs.Untitled_32sceneCode.GDCard2Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard4Objects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard4Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard4Objects2_2final.push(gdjs.Untitled_32sceneCode.GDCard4Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);
{let isConditionTrue_3 = false;
isConditionTrue_3 = false;
{isConditionTrue_3 = (((gdjs.Untitled_32sceneCode.GDCard3Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard3Objects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_3) {
isConditionTrue_3 = false;
{isConditionTrue_3 = (((gdjs.Untitled_32sceneCode.GDCard4Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard4Objects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
}
isConditionTrue_2 = isConditionTrue_3;
}
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard3Objects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard3Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard3Objects2_2final.push(gdjs.Untitled_32sceneCode.GDCard3Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard4Objects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard4Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard4Objects2_2final.push(gdjs.Untitled_32sceneCode.GDCard4Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard1Objects2_2final, gdjs.Untitled_32sceneCode.GDCard1Objects2);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard2Objects2_2final, gdjs.Untitled_32sceneCode.GDCard2Objects2);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard3Objects2_2final, gdjs.Untitled_32sceneCode.GDCard3Objects2);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard4Objects2_2final, gdjs.Untitled_32sceneCode.GDCard4Objects2);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_2final, gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2);
}
}
isConditionTrue_0 = !isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10810796);
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.Untitled_32sceneCode.asyncCallback10939684 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(false);
}gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList32 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback10939684(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.asyncCallback10905732 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(7).add(50 * runtimeScene.getScene().getVariables().getFromIndex(14).getAsNumber());
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList32(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList33 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback10905732(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.asyncCallback9890316 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(false);
}gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList34 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback9890316(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.asyncCallback9379620 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(7).sub(50 * runtimeScene.getScene().getVariables().getFromIndex(15).getAsNumber());
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList34(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList35 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback9379620(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.eventsList36 = function(runtimeScene) {

{

gdjs.Untitled_32sceneCode.GDCard1Objects2.length = 0;

gdjs.Untitled_32sceneCode.GDCard2Objects2.length = 0;

gdjs.Untitled_32sceneCode.GDCard3Objects2.length = 0;

gdjs.Untitled_32sceneCode.GDCard4Objects2.length = 0;

gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(6).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber() == 50);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Untitled_32sceneCode.GDCard1Objects2_1final.length = 0;
gdjs.Untitled_32sceneCode.GDCard2Objects2_1final.length = 0;
gdjs.Untitled_32sceneCode.GDCard3Objects2_1final.length = 0;
gdjs.Untitled_32sceneCode.GDCard4Objects2_1final.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDCard1Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard1Objects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDCard2Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard2Objects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDCard3Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard3Objects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard1Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard1Objects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard1Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard1Objects2_1final.push(gdjs.Untitled_32sceneCode.GDCard1Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard2Objects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard2Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard2Objects2_1final.push(gdjs.Untitled_32sceneCode.GDCard2Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard3Objects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard3Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard3Objects2_1final.push(gdjs.Untitled_32sceneCode.GDCard3Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_1final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDCard1Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard1Objects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDCard2Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard2Objects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDCard4Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard4Objects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard1Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard1Objects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard1Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard1Objects2_1final.push(gdjs.Untitled_32sceneCode.GDCard1Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard2Objects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard2Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard2Objects2_1final.push(gdjs.Untitled_32sceneCode.GDCard2Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard4Objects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard4Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard4Objects2_1final.push(gdjs.Untitled_32sceneCode.GDCard4Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_1final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDCard2Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard2Objects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDCard3Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard3Objects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (((gdjs.Untitled_32sceneCode.GDCard4Objects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard4Objects3[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[0].getVariables()).getFromIndex(0).getAsNumber());
}
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard2Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard2Objects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard2Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard2Objects2_1final.push(gdjs.Untitled_32sceneCode.GDCard2Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard3Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard3Objects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard3Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard3Objects2_1final.push(gdjs.Untitled_32sceneCode.GDCard3Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard4Objects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard4Objects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDCard4Objects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard4Objects2_1final.push(gdjs.Untitled_32sceneCode.GDCard4Objects3[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_1final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_1final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard1Objects2_1final, gdjs.Untitled_32sceneCode.GDCard1Objects2);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard2Objects2_1final, gdjs.Untitled_32sceneCode.GDCard2Objects2);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard3Objects2_1final, gdjs.Untitled_32sceneCode.GDCard3Objects2);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard4Objects2_1final, gdjs.Untitled_32sceneCode.GDCard4Objects2);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2_1final, gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10900180);
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList33(runtimeScene);} //End of subevents
}

}


{

gdjs.Untitled_32sceneCode.GDCard1Objects1.length = 0;

gdjs.Untitled_32sceneCode.GDCard2Objects1.length = 0;

gdjs.Untitled_32sceneCode.GDCard3Objects1.length = 0;

gdjs.Untitled_32sceneCode.GDCard4Objects1.length = 0;

gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(6).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber() == 50);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
{gdjs.Untitled_32sceneCode.GDCard1Objects1_2final.length = 0;
gdjs.Untitled_32sceneCode.GDCard2Objects1_2final.length = 0;
gdjs.Untitled_32sceneCode.GDCard3Objects1_2final.length = 0;
gdjs.Untitled_32sceneCode.GDCard4Objects1_2final.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2);
{let isConditionTrue_3 = false;
isConditionTrue_3 = false;
{isConditionTrue_3 = (((gdjs.Untitled_32sceneCode.GDCard1Objects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard1Objects2[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_3) {
isConditionTrue_3 = false;
{isConditionTrue_3 = (((gdjs.Untitled_32sceneCode.GDCard2Objects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard2Objects2[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_3) {
isConditionTrue_3 = false;
{isConditionTrue_3 = (((gdjs.Untitled_32sceneCode.GDCard3Objects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard3Objects2[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[0].getVariables()).getFromIndex(0).getAsNumber());
}
}
}
isConditionTrue_2 = isConditionTrue_3;
}
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard1Objects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard1Objects1_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard1Objects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard1Objects1_2final.push(gdjs.Untitled_32sceneCode.GDCard1Objects2[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard2Objects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard2Objects1_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard2Objects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard2Objects1_2final.push(gdjs.Untitled_32sceneCode.GDCard2Objects2[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard3Objects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard3Objects1_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard3Objects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard3Objects1_2final.push(gdjs.Untitled_32sceneCode.GDCard3Objects2[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1_2final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1_2final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2);
{let isConditionTrue_3 = false;
isConditionTrue_3 = false;
{isConditionTrue_3 = (((gdjs.Untitled_32sceneCode.GDCard1Objects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard1Objects2[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_3) {
isConditionTrue_3 = false;
{isConditionTrue_3 = (((gdjs.Untitled_32sceneCode.GDCard2Objects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard2Objects2[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_3) {
isConditionTrue_3 = false;
{isConditionTrue_3 = (((gdjs.Untitled_32sceneCode.GDCard4Objects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard4Objects2[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[0].getVariables()).getFromIndex(0).getAsNumber());
}
}
}
isConditionTrue_2 = isConditionTrue_3;
}
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard1Objects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard1Objects1_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard1Objects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard1Objects1_2final.push(gdjs.Untitled_32sceneCode.GDCard1Objects2[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard2Objects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard2Objects1_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard2Objects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard2Objects1_2final.push(gdjs.Untitled_32sceneCode.GDCard2Objects2[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard4Objects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard4Objects1_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard4Objects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard4Objects1_2final.push(gdjs.Untitled_32sceneCode.GDCard4Objects2[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1_2final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1_2final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2);
{let isConditionTrue_3 = false;
isConditionTrue_3 = false;
{isConditionTrue_3 = (((gdjs.Untitled_32sceneCode.GDCard2Objects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard2Objects2[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_3) {
isConditionTrue_3 = false;
{isConditionTrue_3 = (((gdjs.Untitled_32sceneCode.GDCard3Objects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard3Objects2[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[0].getVariables()).getFromIndex(0).getAsNumber());
}
if (isConditionTrue_3) {
isConditionTrue_3 = false;
{isConditionTrue_3 = (((gdjs.Untitled_32sceneCode.GDCard4Objects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDCard4Objects2[0].getVariables()).getFromIndex(0).getAsNumber() == ((gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[0].getVariables()).getFromIndex(0).getAsNumber());
}
}
}
isConditionTrue_2 = isConditionTrue_3;
}
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard2Objects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard2Objects1_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard2Objects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard2Objects1_2final.push(gdjs.Untitled_32sceneCode.GDCard2Objects2[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard3Objects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard3Objects1_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard3Objects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard3Objects1_2final.push(gdjs.Untitled_32sceneCode.GDCard3Objects2[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDCard4Objects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDCard4Objects1_2final.indexOf(gdjs.Untitled_32sceneCode.GDCard4Objects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDCard4Objects1_2final.push(gdjs.Untitled_32sceneCode.GDCard4Objects2[j]);
    }
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1_2final.indexOf(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1_2final.push(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard1Objects1_2final, gdjs.Untitled_32sceneCode.GDCard1Objects1);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard2Objects1_2final, gdjs.Untitled_32sceneCode.GDCard2Objects1);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard3Objects1_2final, gdjs.Untitled_32sceneCode.GDCard3Objects1);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDCard4Objects1_2final, gdjs.Untitled_32sceneCode.GDCard4Objects1);
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1_2final, gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1);
}
}
isConditionTrue_0 = !isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10642540);
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList35(runtimeScene);} //End of subevents
}

}


};gdjs.Untitled_32sceneCode.eventsList37 = function(runtimeScene) {

{


gdjs.Untitled_32sceneCode.eventsList16(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList21(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList26(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList31(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList36(runtimeScene);
}


};gdjs.Untitled_32sceneCode.eventsList38 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[k] = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[k] = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i].getBehavior("Animation").setAnimationName("Red");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i].returnVariable(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[k] = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i].getVariables().getFromIndex(0)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[k] = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i].getBehavior("Animation").setAnimationName("Blue");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i].returnVariable(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[k] = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i].getVariables().getFromIndex(0)) == 3 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[k] = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i].getBehavior("Animation").setAnimationName("Yellow");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i].returnVariable(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[k] = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i].getVariables().getFromIndex(0)) == 4 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[k] = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i].getBehavior("Animation").setAnimationName("Green");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i].returnVariable(gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


};gdjs.Untitled_32sceneCode.eventsList39 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard1Objects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard1Objects3[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDCard1Objects3[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard1Objects3[k] = gdjs.Untitled_32sceneCode.GDCard1Objects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard1Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard1Objects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard1Objects3[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDCard1Objects3[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard1Objects3[k] = gdjs.Untitled_32sceneCode.GDCard1Objects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard1Objects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCard1Objects3 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects3[i].getBehavior("Animation").setAnimationName("Red");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects3[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard1Objects3[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard1Objects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard1Objects3[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDCard1Objects3[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard1Objects3[k] = gdjs.Untitled_32sceneCode.GDCard1Objects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard1Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard1Objects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard1Objects3[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDCard1Objects3[i].getVariables().getFromIndex(0)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard1Objects3[k] = gdjs.Untitled_32sceneCode.GDCard1Objects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard1Objects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCard1Objects3 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects3[i].getBehavior("Animation").setAnimationName("Blue");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects3[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard1Objects3[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard1Objects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard1Objects3[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDCard1Objects3[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard1Objects3[k] = gdjs.Untitled_32sceneCode.GDCard1Objects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard1Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard1Objects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard1Objects3[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDCard1Objects3[i].getVariables().getFromIndex(0)) == 3 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard1Objects3[k] = gdjs.Untitled_32sceneCode.GDCard1Objects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard1Objects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCard1Objects3 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects3[i].getBehavior("Animation").setAnimationName("Yellow");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects3[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard1Objects3[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard1Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard1Objects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDCard1Objects2[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard1Objects2[k] = gdjs.Untitled_32sceneCode.GDCard1Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard1Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard1Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard1Objects2[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDCard1Objects2[i].getVariables().getFromIndex(0)) == 4 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard1Objects2[k] = gdjs.Untitled_32sceneCode.GDCard1Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard1Objects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCard1Objects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects2[i].getBehavior("Animation").setAnimationName("Green");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects2[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard1Objects2[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


};gdjs.Untitled_32sceneCode.eventsList40 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard2Objects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard2Objects3[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDCard2Objects3[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard2Objects3[k] = gdjs.Untitled_32sceneCode.GDCard2Objects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard2Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard2Objects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard2Objects3[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDCard2Objects3[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard2Objects3[k] = gdjs.Untitled_32sceneCode.GDCard2Objects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard2Objects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCard2Objects3 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects3[i].getBehavior("Animation").setAnimationName("Red");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects3[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard2Objects3[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard2Objects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard2Objects3[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDCard2Objects3[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard2Objects3[k] = gdjs.Untitled_32sceneCode.GDCard2Objects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard2Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard2Objects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard2Objects3[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDCard2Objects3[i].getVariables().getFromIndex(0)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard2Objects3[k] = gdjs.Untitled_32sceneCode.GDCard2Objects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard2Objects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCard2Objects3 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects3[i].getBehavior("Animation").setAnimationName("Blue");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects3[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard2Objects3[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard2Objects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard2Objects3[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDCard2Objects3[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard2Objects3[k] = gdjs.Untitled_32sceneCode.GDCard2Objects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard2Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard2Objects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard2Objects3[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDCard2Objects3[i].getVariables().getFromIndex(0)) == 3 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard2Objects3[k] = gdjs.Untitled_32sceneCode.GDCard2Objects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard2Objects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCard2Objects3 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects3[i].getBehavior("Animation").setAnimationName("Yellow");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects3[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard2Objects3[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard2Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard2Objects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDCard2Objects2[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard2Objects2[k] = gdjs.Untitled_32sceneCode.GDCard2Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard2Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard2Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard2Objects2[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDCard2Objects2[i].getVariables().getFromIndex(0)) == 4 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard2Objects2[k] = gdjs.Untitled_32sceneCode.GDCard2Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard2Objects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCard2Objects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects2[i].getBehavior("Animation").setAnimationName("Green");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects2[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard2Objects2[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


};gdjs.Untitled_32sceneCode.eventsList41 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard3Objects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard3Objects3[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDCard3Objects3[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard3Objects3[k] = gdjs.Untitled_32sceneCode.GDCard3Objects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard3Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard3Objects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard3Objects3[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDCard3Objects3[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard3Objects3[k] = gdjs.Untitled_32sceneCode.GDCard3Objects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard3Objects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCard3Objects3 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects3[i].getBehavior("Animation").setAnimationName("Red");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects3[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard3Objects3[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard3Objects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard3Objects3[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDCard3Objects3[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard3Objects3[k] = gdjs.Untitled_32sceneCode.GDCard3Objects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard3Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard3Objects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard3Objects3[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDCard3Objects3[i].getVariables().getFromIndex(0)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard3Objects3[k] = gdjs.Untitled_32sceneCode.GDCard3Objects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard3Objects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCard3Objects3 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects3[i].getBehavior("Animation").setAnimationName("Blue");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects3[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard3Objects3[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard3Objects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard3Objects3[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDCard3Objects3[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard3Objects3[k] = gdjs.Untitled_32sceneCode.GDCard3Objects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard3Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard3Objects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard3Objects3[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDCard3Objects3[i].getVariables().getFromIndex(0)) == 3 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard3Objects3[k] = gdjs.Untitled_32sceneCode.GDCard3Objects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard3Objects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCard3Objects3 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects3[i].getBehavior("Animation").setAnimationName("Yellow");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects3[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard3Objects3[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard3Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard3Objects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDCard3Objects2[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard3Objects2[k] = gdjs.Untitled_32sceneCode.GDCard3Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard3Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard3Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard3Objects2[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDCard3Objects2[i].getVariables().getFromIndex(0)) == 4 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard3Objects2[k] = gdjs.Untitled_32sceneCode.GDCard3Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard3Objects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCard3Objects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects2[i].getBehavior("Animation").setAnimationName("Green");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects2[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard3Objects2[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


};gdjs.Untitled_32sceneCode.eventsList42 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard4Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard4Objects2[k] = gdjs.Untitled_32sceneCode.GDCard4Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard4Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard4Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard4Objects2[k] = gdjs.Untitled_32sceneCode.GDCard4Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard4Objects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCard4Objects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getBehavior("Animation").setAnimationName("Red");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects2[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard4Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard4Objects2[k] = gdjs.Untitled_32sceneCode.GDCard4Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard4Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard4Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getVariables().getFromIndex(0)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard4Objects2[k] = gdjs.Untitled_32sceneCode.GDCard4Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard4Objects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCard4Objects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getBehavior("Animation").setAnimationName("Blue");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects2[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard4Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard4Objects2[k] = gdjs.Untitled_32sceneCode.GDCard4Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard4Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard4Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getVariables().getFromIndex(0)) == 3 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard4Objects2[k] = gdjs.Untitled_32sceneCode.GDCard4Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard4Objects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCard4Objects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getBehavior("Animation").setAnimationName("Yellow");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects2[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard4Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard4Objects1[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDCard4Objects1[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard4Objects1[k] = gdjs.Untitled_32sceneCode.GDCard4Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard4Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDCard4Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDCard4Objects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDCard4Objects1[i].getVariables().getFromIndex(0)) == 4 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDCard4Objects1[k] = gdjs.Untitled_32sceneCode.GDCard4Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDCard4Objects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCard4Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects1[i].getBehavior("Animation").setAnimationName("Green");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDCard4Objects1[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


};gdjs.Untitled_32sceneCode.eventsList43 = function(runtimeScene) {

{


gdjs.Untitled_32sceneCode.eventsList38(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList39(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList40(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList41(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList42(runtimeScene);
}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBet_95959595Pair_95959595ButtonObjects2Objects = Hashtable.newFrom({"Bet_Pair_Button": gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBet_95959595One_95959595Of_95959595Each_95959595ButtonObjects2Objects = Hashtable.newFrom({"Bet_One_Of_Each_Button": gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBet_95959595High_95959595Card_95959595ButtonObjects2Objects = Hashtable.newFrom({"Bet_High_Card_Button": gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBet_95959595Three_95959595Of_95959595A_95959595Kind_95959595ButtonObjects2Objects = Hashtable.newFrom({"Bet_Three_Of_A_Kind_Button": gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBet_95959595Four_95959595Of_95959595A_95959595Kind_95959595ButtonObjects1Objects = Hashtable.newFrom({"Bet_Four_Of_A_Kind_Button": gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects1});
gdjs.Untitled_32sceneCode.eventsList44 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Bet_Pair_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBet_95959595Pair_95959595ButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2[i].getBehavior("Opacity").getOpacity() == 255 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2[k] = gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(10);
}{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bet_One_Of_Each_Button"), gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBet_95959595One_95959595Of_95959595Each_95959595ButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2[i].getBehavior("Opacity").getOpacity() == 255 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2[k] = gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(20);
}{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bet_High_Card_Button"), gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBet_95959595High_95959595Card_95959595ButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2[i].getBehavior("Opacity").getOpacity() == 255 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2[k] = gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(30);
}{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bet_Three_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBet_95959595Three_95959595Of_95959595A_95959595Kind_95959595ButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2[i].getBehavior("Opacity").getOpacity() == 255 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2[k] = gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(40);
}{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bet_Four_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBet_95959595Four_95959595Of_95959595A_95959595Kind_95959595ButtonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects1[i].getBehavior("Opacity").getOpacity() == 255 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects1[k] = gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(50);
}{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(true);
}}

}


};gdjs.Untitled_32sceneCode.asyncCallback10518068 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("gameovertext"), gdjs.Untitled_32sceneCode.GDgameovertextObjects3);

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgameovertextObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgameovertextObjects3[i].getBehavior("Tween").addObjectOpacityTween2("fade", 255, "linear", 1, false);
}
}gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.eventsList45 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
for (const obj of gdjs.Untitled_32sceneCode.GDgameovertextObjects2) asyncObjectsList.addObject("gameovertext", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback10518068(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Untitled_32sceneCode.eventsList46 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Rules"), gdjs.Untitled_32sceneCode.GDRulesObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDRulesObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDRulesObjects2[i].getBehavior("Opacity").getOpacity() == 255 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDRulesObjects2[k] = gdjs.Untitled_32sceneCode.GDRulesObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDRulesObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDRulesObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRulesObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRulesObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Double_Points_Button"), gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("PointsDisplay"), gdjs.Untitled_32sceneCode.GDPointsDisplayObjects2);
gdjs.copyArray(runtimeScene.getObjects("ReduceLossPointsButtonText"), gdjs.Untitled_32sceneCode.GDReduceLossPointsButtonTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Reduced_Loss_Button"), gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("RoundsDisplay"), gdjs.Untitled_32sceneCode.GDRoundsDisplayObjects2);
gdjs.copyArray(runtimeScene.getObjects("Start_Button"), gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Start_Hand_Text"), gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("YourCardText"), gdjs.Untitled_32sceneCode.GDYourCardTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("choosetext"), gdjs.Untitled_32sceneCode.GDchoosetextObjects2);
gdjs.copyArray(runtimeScene.getObjects("x2PointsButtonText"), gdjs.Untitled_32sceneCode.GDx2PointsButtonTextObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPointsDisplayObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPointsDisplayObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(7))));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRoundsDisplayObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRoundsDisplayObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2))));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDYourCardTextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDYourCardTextObjects2[i].getBehavior("Opacity").setOpacity((( gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[0].getBehavior("Opacity").getOpacity()));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2[i].getBehavior("Opacity").setOpacity((( gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2[0].getBehavior("Opacity").getOpacity()));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDx2PointsButtonTextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDx2PointsButtonTextObjects2[i].getBehavior("Opacity").setOpacity((( gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2[0].getBehavior("Opacity").getOpacity()));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDReduceLossPointsButtonTextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDReduceLossPointsButtonTextObjects2[i].getBehavior("Opacity").setOpacity((( gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects2[0].getBehavior("Opacity").getOpacity()));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDchoosetextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDchoosetextObjects2[i].getBehavior("Opacity").setOpacity((( gdjs.Untitled_32sceneCode.GDx2PointsButtonTextObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDx2PointsButtonTextObjects2[0].getBehavior("Opacity").getOpacity()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber() <= 0);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bet_Four_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_High_Card_Button"), gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_One_Of_Each_Button"), gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_Pair_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Bet_Three_Of_A_Kind_Button"), gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Board"), gdjs.Untitled_32sceneCode.GDBoardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Card1"), gdjs.Untitled_32sceneCode.GDCard1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card2"), gdjs.Untitled_32sceneCode.GDCard2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card3"), gdjs.Untitled_32sceneCode.GDCard3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Card4"), gdjs.Untitled_32sceneCode.GDCard4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Dealer_Deck"), gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2);
gdjs.copyArray(runtimeScene.getObjects("Doors_Animation"), gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player_Card"), gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Start_Button"), gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Start_Hand_Text"), gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("gameovertext"), gdjs.Untitled_32sceneCode.GDgameovertextObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard1Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard1Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard2Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard3Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard3Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCard4Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCard4Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoardObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoardObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{runtimeScene.getScene().getVariables().getFromIndex(11).setBoolean(false);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgameovertextObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgameovertextObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects2[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects2[i].getBehavior("Animation").setAnimationName("Doors_Opening");
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects2[i].getBehavior("Animation").resumeAnimation();
}
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList45(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() > 5);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ThresholdsDisplay"), gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects2[i].getBehavior("Text").setText("REQ : 200");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() > 11);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ThresholdsDisplay"), gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects2[i].getBehavior("Text").setText("REQ : 275");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() > 17);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ThresholdsDisplay"), gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects2[i].getBehavior("Text").setText("REQ : 350");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Board"), gdjs.Untitled_32sceneCode.GDBoardObjects1);
gdjs.copyArray(runtimeScene.getObjects("Dealer_Deck"), gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects1);
gdjs.copyArray(runtimeScene.getObjects("Start_Button"), gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoardObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoardObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}}

}


};gdjs.Untitled_32sceneCode.eventsList47 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Doors_Animation"), gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects1);
gdjs.copyArray(runtimeScene.getObjects("Rules"), gdjs.Untitled_32sceneCode.GDRulesObjects1);
gdjs.copyArray(runtimeScene.getObjects("RulesButton"), gdjs.Untitled_32sceneCode.GDRulesButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Start_Button"), gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Start_Hand_Text"), gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects1);
gdjs.copyArray(runtimeScene.getObjects("gameovertext"), gdjs.Untitled_32sceneCode.GDgameovertextObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects1[i].getBehavior("Animation").pauseAnimation();
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setBoolean(false);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgameovertextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgameovertextObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects1[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects1[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRulesButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRulesButtonObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRulesObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRulesObjects1[i].getBehavior("Opacity").setOpacity(255);
}
}{runtimeScene.getScene().getVariables().getFromIndex(11).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(7).setNumber(100);
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(-(1));
}{runtimeScene.getScene().getVariables().getFromIndex(14).setNumber(1);
}{runtimeScene.getScene().getVariables().getFromIndex(15).setNumber(1);
}}

}


{


gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList1(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList2(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList7(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList8(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList11(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList37(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList43(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList44(runtimeScene);
}


{


gdjs.Untitled_32sceneCode.eventsList46(runtimeScene);
}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDCard1Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDCard1Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDCard1Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDCard1Objects4.length = 0;
gdjs.Untitled_32sceneCode.GDCard1Objects5.length = 0;
gdjs.Untitled_32sceneCode.GDBoardObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBoardObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBoardObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBoardObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDBoardObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDPointsDisplayObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPointsDisplayObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPointsDisplayObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDPointsDisplayObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDPointsDisplayObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDgameovertextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDgameovertextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDgameovertextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDgameovertextObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDgameovertextObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDRoundsDisplayObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRoundsDisplayObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRoundsDisplayObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDRoundsDisplayObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDRoundsDisplayObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDCard2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDCard2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDCard2Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDCard2Objects4.length = 0;
gdjs.Untitled_32sceneCode.GDCard2Objects5.length = 0;
gdjs.Untitled_32sceneCode.GDCard3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDCard3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDCard3Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDCard3Objects4.length = 0;
gdjs.Untitled_32sceneCode.GDCard3Objects5.length = 0;
gdjs.Untitled_32sceneCode.GDCard4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDCard4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDCard4Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDCard4Objects4.length = 0;
gdjs.Untitled_32sceneCode.GDCard4Objects5.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDYourCardTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDYourCardTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDYourCardTextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDYourCardTextObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDYourCardTextObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDPointsTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPointsTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPointsTextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDPointsTextObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDPointsTextObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDHandsElapsedTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDHandsElapsedTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDHandsElapsedTextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDHandsElapsedTextObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDHandsElapsedTextObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDBackgroundObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBackgroundObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBackgroundObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBackgroundObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDBackgroundObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDx2PointsButtonTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDx2PointsButtonTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDx2PointsButtonTextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDx2PointsButtonTextObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDx2PointsButtonTextObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDchoosetextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDchoosetextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDchoosetextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDchoosetextObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDchoosetextObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDReduceLossPointsButtonTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDReduceLossPointsButtonTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDReduceLossPointsButtonTextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDReduceLossPointsButtonTextObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDReduceLossPointsButtonTextObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDRulesObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRulesObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRulesObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDRulesObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDRulesObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDRulesButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRulesButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRulesButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDRulesButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDRulesButtonObjects5.length = 0;

gdjs.Untitled_32sceneCode.eventsList47(runtimeScene);
gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDDealer_9595DeckObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDCard1Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDCard1Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDCard1Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDCard1Objects4.length = 0;
gdjs.Untitled_32sceneCode.GDCard1Objects5.length = 0;
gdjs.Untitled_32sceneCode.GDBoardObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBoardObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBoardObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBoardObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDBoardObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDStart_9595ButtonObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Pair_9595ButtonObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595One_9595Of_9595Each_9595ButtonObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595High_9595Card_9595ButtonObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Three_9595Of_9595A_9595Kind_9595ButtonObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDBet_9595Four_9595Of_9595A_9595Kind_9595ButtonObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDPointsDisplayObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPointsDisplayObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPointsDisplayObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDPointsDisplayObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDPointsDisplayObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDgameovertextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDgameovertextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDgameovertextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDgameovertextObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDgameovertextObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDRoundsDisplayObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRoundsDisplayObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRoundsDisplayObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDRoundsDisplayObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDRoundsDisplayObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDThresholdsDisplayObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDDouble_9595Points_9595ButtonObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDReduced_9595Loss_9595ButtonObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDCard2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDCard2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDCard2Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDCard2Objects4.length = 0;
gdjs.Untitled_32sceneCode.GDCard2Objects5.length = 0;
gdjs.Untitled_32sceneCode.GDCard3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDCard3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDCard3Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDCard3Objects4.length = 0;
gdjs.Untitled_32sceneCode.GDCard3Objects5.length = 0;
gdjs.Untitled_32sceneCode.GDCard4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDCard4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDCard4Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDCard4Objects4.length = 0;
gdjs.Untitled_32sceneCode.GDCard4Objects5.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer_9595CardObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDYourCardTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDYourCardTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDYourCardTextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDYourCardTextObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDYourCardTextObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDStart_9595Hand_9595TextObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDPointsTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPointsTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPointsTextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDPointsTextObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDPointsTextObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDHandsElapsedTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDHandsElapsedTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDHandsElapsedTextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDHandsElapsedTextObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDHandsElapsedTextObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDDoors_9595AnimationObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDBackgroundObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBackgroundObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBackgroundObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBackgroundObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDBackgroundObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDx2PointsButtonTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDx2PointsButtonTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDx2PointsButtonTextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDx2PointsButtonTextObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDx2PointsButtonTextObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDchoosetextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDchoosetextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDchoosetextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDchoosetextObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDchoosetextObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDReduceLossPointsButtonTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDReduceLossPointsButtonTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDReduceLossPointsButtonTextObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDReduceLossPointsButtonTextObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDReduceLossPointsButtonTextObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDRulesObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRulesObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRulesObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDRulesObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDRulesObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDRulesButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRulesButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRulesButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDRulesButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDRulesButtonObjects5.length = 0;


return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
